package com.example.customdiscs;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.RecordItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CustomDiscs.MODID)
public class CustomDiscs {
    public static final String MODID = "customdiscs";

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<SoundEvent> DEEMO_ENTRANCE_SOUND = SOUNDS.register(
            "music_disc.deemo_entrance",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "music_disc.deemo_entrance")));
    public static final RegistryObject<SoundEvent> HAI_YO_BERSERK_SOUND = SOUNDS.register(
            "music_disc.hai_yo_berserk",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "music_disc.hai_yo_berserk")));
    public static final RegistryObject<SoundEvent> DEEMO_REBORN_SQUEAKY_MIND_SOUND = SOUNDS.register(
            "music_disc.deemo_reborn_squeaky_mind",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "music_disc.deemo_reborn_squeaky_mind")));
    public static final RegistryObject<SoundEvent> EXODUS_SOUND = SOUNDS.register(
            "music_disc.exodus",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "music_disc.exodus")));
    public static final RegistryObject<SoundEvent> WONDER_OF_YOU_SOUND = SOUNDS.register(
            "music_disc.wonder_of_you",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(MODID, "music_disc.wonder_of_you")));

    // Last argument = track length in ticks (seconds * 20)
    public static final RegistryObject<Item> DEEMO_ENTRANCE_DISC = ITEMS.register(
            "music_disc_deemo_entrance",
            () -> new RecordItem(13, DEEMO_ENTRANCE_SOUND, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 251 * 20));
    public static final RegistryObject<Item> HAI_YO_BERSERK_DISC = ITEMS.register(
            "music_disc_hai_yo_berserk",
            () -> new RecordItem(14, HAI_YO_BERSERK_SOUND, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 114 * 20));
    public static final RegistryObject<Item> DEEMO_REBORN_SQUEAKY_MIND_DISC = ITEMS.register(
            "music_disc_deemo_reborn_squeaky_mind",
            () -> new RecordItem(15, DEEMO_REBORN_SQUEAKY_MIND_SOUND, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 146 * 20));
    public static final RegistryObject<Item> EXODUS_DISC = ITEMS.register(
            "music_disc_exodus",
            () -> new RecordItem(12, EXODUS_SOUND, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 183 * 20));
    public static final RegistryObject<Item> WONDER_OF_YOU_DISC = ITEMS.register(
            "music_disc_wonder_of_you",
            () -> new RecordItem(11, WONDER_OF_YOU_SOUND, new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 147 * 20));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("customdiscs",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.customdiscs"))
                    .icon(() -> new ItemStack(DEEMO_ENTRANCE_DISC.get()))
                    .displayItems((params, output) -> {
                        output.accept(DEEMO_ENTRANCE_DISC.get());
                        output.accept(HAI_YO_BERSERK_DISC.get());
                        output.accept(DEEMO_REBORN_SQUEAKY_MIND_DISC.get());
                        output.accept(EXODUS_DISC.get());
                        output.accept(WONDER_OF_YOU_DISC.get());
                    })
                    .build());

    public CustomDiscs() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        SOUNDS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
