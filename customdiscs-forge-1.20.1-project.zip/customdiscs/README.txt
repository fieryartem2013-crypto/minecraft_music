Custom Discs (Forge 1.20.1) - Deemo "Entrance" + Berserk "Hai Yo"

СБОРКА (нужна Java 17):
  Windows:  gradlew.bat build
  Linux/Mac: ./gradlew build
Готовый мод: build/libs/customdiscs-1.20.1-1.0.0.jar -> положить в папку mods.

Выдать пластинки командой:
  /give @p customdiscs:music_disc_deemo_entrance
  /give @p customdiscs:music_disc_hai_yo_berserk
  /give @p customdiscs:music_disc_deemo_reborn_squeaky_mind
  /give @p customdiscs:music_disc_exodus
  /give @p customdiscs:music_disc_wonder_of_you
Также они есть во вкладке творческого режима "Custom Discs".

СБОРКА БЕЗ УСТАНОВКИ JAVA (через GitHub):
  1) Создай пустой репозиторий на github.com и загрузи в него ВСЕ файлы этой папки
     (включая скрытую папку .github).
  2) Вкладка Actions -> Build mod -> дождись зелёной галочки.
  3) Открой запуск -> внизу Artifacts -> customdiscs-jar -> внутри будет готовый .jar.
