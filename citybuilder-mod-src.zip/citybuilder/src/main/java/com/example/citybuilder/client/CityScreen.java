package com.example.citybuilder.client;

import com.example.citybuilder.net.BuildCityPacket;
import com.example.citybuilder.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Меню подтверждения: поворот, высота, ОК. Призрак остаётся виден за экраном. */
public class CityScreen extends Screen {
    public CityScreen() { super(Component.translatable("screen.citybuilder.title")); }

    @Override
    protected void init() {
        int w = 150, h = 20, x = this.width / 2 - w / 2, y = this.height / 2 - 40;
        addRenderableWidget(Button.builder(Component.translatable("button.citybuilder.rotate"), b -> ClientHooks.rot = (ClientHooks.rot + 1) & 3).bounds(x, y, w, h).build());
        addRenderableWidget(Button.builder(Component.translatable("button.citybuilder.up"), b -> ClientHooks.yOff++).bounds(x, y + 24, 73, h).build());
        addRenderableWidget(Button.builder(Component.translatable("button.citybuilder.down"), b -> ClientHooks.yOff--).bounds(x + 77, y + 24, 73, h).build());
        addRenderableWidget(Button.builder(Component.translatable("button.citybuilder.build"), b -> {
            if (ClientHooks.buildPos() != null) Net.CH.sendToServer(new BuildCityPacket(ClientHooks.buildPos(), ClientHooks.rot));
            ClientHooks.cancel();
            onClose();
        }).bounds(x, y + 52, w, h).build());
        addRenderableWidget(Button.builder(Component.translatable("button.citybuilder.cancel"), b -> { ClientHooks.cancel(); onClose(); }).bounds(x, y + 76, w, h).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        // без затемнения фона — призрак города остаётся виден
        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 62, 0xFFFFFF);
        super.render(g, mx, my, pt);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
