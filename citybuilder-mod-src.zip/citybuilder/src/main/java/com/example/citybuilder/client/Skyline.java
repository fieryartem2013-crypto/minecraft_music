package com.example.citybuilder.client;

import com.example.citybuilder.build.BlockBuffer;
import com.example.citybuilder.build.CityGenerator;
import com.example.citybuilder.build.Layout;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

/** Лёгкая "карта высот" города для призрачного превью: по колонке — верхняя точка и цвет. */
public final class Skyline {
    public static final int P = Layout.PAD, N = 2 * P + 1;
    public static final int NONE = Integer.MIN_VALUE;
    public final int[] top = new int[N * N];
    public final int[] rgb = new int[N * N];

    private static volatile Skyline instance;
    private static volatile boolean loading;

    public static Skyline get() { return instance; }
    public static boolean isLoading() { return loading; }

    public static void loadAsync() {
        if (instance != null || loading) return;
        loading = true;
        Thread t = new Thread(() -> {
            try {
                BlockBuffer b = CityGenerator.build();
                Skyline s = new Skyline();
                java.util.Arrays.fill(s.top, NONE);
                for (Long2ObjectMap.Entry<BlockState> e : b.map.long2ObjectEntrySet()) {
                    long k = e.getLongKey();
                    int y = BlockPos.getY(k);
                    BlockState st = e.getValue();
                    if (y < 0 || st.isAir()) continue;
                    int x = BlockPos.getX(k), z = BlockPos.getZ(k);
                    if (x < -P || x > P || z < -P || z > P) continue;
                    int i = (x + P) * N + (z + P);
                    if (y > s.top[i]) { s.top[i] = y; s.rgb[i] = color(st); }
                }
                instance = s;
            } catch (Throwable ex) {
                ex.printStackTrace();
            } finally {
                loading = false;
            }
        }, "citybuilder-skyline");
        t.setDaemon(true);
        t.start();
    }

    private static int color(BlockState st) {
        MapColor mc = st.getMapColor(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
        int c = mc == null ? 0 : mc.col;
        return c == 0 ? 0x9AA0A6 : c;
    }

    /** Вершина колонки (x,z) в повёрнутом на rot*90° пространстве. */
    public int topAt(int rx, int rz, int rot) {
        int x = rx, z = rz;
        for (int i = 0; i < rot; i++) { int t = x; x = z; z = -t; } // обратный поворот
        if (x < -P || x > P || z < -P || z > P) return NONE;
        return top[(x + P) * N + (z + P)];
    }

    public int colorAt(int rx, int rz, int rot) {
        int x = rx, z = rz;
        for (int i = 0; i < rot; i++) { int t = x; x = z; z = -t; }
        return rgb[(x + P) * N + (z + P)];
    }
}
