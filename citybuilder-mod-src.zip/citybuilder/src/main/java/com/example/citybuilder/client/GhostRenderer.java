package com.example.citybuilder.client;

import com.example.citybuilder.CityBuilderMod;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Рисует призрачную (полупрозрачную) копию города по "карте высот". Меши запекаются в VBO. */
@Mod.EventBusSubscriber(modid = CityBuilderMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GhostRenderer {
    private static final VertexBuffer[] VBO = new VertexBuffer[4];
    private static Skyline bakedFrom;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END) ClientHooks.tick();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        if (!ClientHooks.active) return;
        BlockPos t = ClientHooks.buildPos();
        Skyline sk = Skyline.get();
        if (t == null || sk == null) return;

        int rot = ClientHooks.rot & 3;
        if (bakedFrom != sk) { for (int i = 0; i < 4; i++) { if (VBO[i] != null) VBO[i].close(); VBO[i] = null; } bakedFrom = sk; }
        if (VBO[rot] == null) VBO[rot] = bake(sk, rot);

        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(t.getX() - cam.x, t.getY() - cam.y, t.getZ() - cam.z);

        long time = Minecraft.getInstance().level == null ? 0 : Minecraft.getInstance().level.getGameTime();
        float alpha = 0.42f + 0.10f * (float) Math.sin(time / 8.0);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);

        VBO[rot].bind();
        VBO[rot].drawWithShader(ps.last().pose(), e.getProjectionMatrix(), RenderSystem.getShader());
        VertexBuffer.unbind();

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ps.popPose();
    }

    private static VertexBuffer bake(Skyline sk, int rot) {
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int P = Skyline.P;
        for (int rx = -P; rx <= P; rx++) for (int rz = -P; rz <= P; rz++) {
            int top = sk.topAt(rx, rz, rot);
            if (top == Skyline.NONE) continue;
            int c = tint(sk.colorAt(rx, rz, rot));
            float y = top + 1;
            quad(bb, rx, y, rz, rx + 1, y, rz, rx + 1, y, rz + 1, rx, y, rz + 1, c, 1.0f);
            side(bb, sk, rot, rx, rz, top, c, 1, 0);
            side(bb, sk, rot, rx, rz, top, c, -1, 0);
            side(bb, sk, rot, rx, rz, top, c, 0, 1);
            side(bb, sk, rot, rx, rz, top, c, 0, -1);
        }
        VertexBuffer vb = new VertexBuffer(VertexBuffer.Usage.STATIC);
        vb.bind();
        vb.upload(bb.end());
        VertexBuffer.unbind();
        return vb;
    }

    private static void side(BufferBuilder bb, Skyline sk, int rot, int rx, int rz, int top, int c, int dx, int dz) {
        int nt = sk.topAt(rx + dx, rz + dz, rot);
        int low = nt == Skyline.NONE ? 0 : nt;
        if (low >= top) return;
        float y0 = low + 1, y1 = top + 1;
        float shade = dx != 0 ? 0.72f : 0.86f;
        if (dx == 1) quad(bb, rx + 1, y0, rz, rx + 1, y0, rz + 1, rx + 1, y1, rz + 1, rx + 1, y1, rz, c, shade);
        else if (dx == -1) quad(bb, rx, y0, rz, rx, y1, rz, rx, y1, rz + 1, rx, y0, rz + 1, c, shade);
        else if (dz == 1) quad(bb, rx, y0, rz + 1, rx, y1, rz + 1, rx + 1, y1, rz + 1, rx + 1, y0, rz + 1, c, shade);
        else quad(bb, rx, y0, rz, rx + 1, y0, rz, rx + 1, y1, rz, rx, y1, rz, c, shade);
    }

    private static void quad(BufferBuilder bb, float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4, int rgb, float shade) {
        int r = (int) (((rgb >> 16) & 255) * shade), g = (int) (((rgb >> 8) & 255) * shade), b = (int) ((rgb & 255) * shade);
        bb.vertex(x1, y1, z1).color(r, g, b, 255).endVertex();
        bb.vertex(x2, y2, z2).color(r, g, b, 255).endVertex();
        bb.vertex(x3, y3, z3).color(r, g, b, 255).endVertex();
        bb.vertex(x4, y4, z4).color(r, g, b, 255).endVertex();
    }

    /** Холодный голубоватый "призрачный" оттенок. */
    private static int tint(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        r = (int) (r * 0.6 + 110 * 0.4); g = (int) (g * 0.6 + 190 * 0.4); b = (int) (b * 0.6 + 255 * 0.4);
        return (r << 16) | (g << 8) | b;
    }

    private GhostRenderer() {}
}
