package com.example.citybuilder.net;

import com.example.citybuilder.build.BuildManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class BuildCityPacket {
    public final BlockPos pos;
    public final int rot;

    public BuildCityPacket(BlockPos pos, int rot) { this.pos = pos; this.rot = rot & 3; }

    public static void encode(BuildCityPacket p, FriendlyByteBuf buf) { buf.writeBlockPos(p.pos); buf.writeByte(p.rot); }
    public static BuildCityPacket decode(FriendlyByteBuf buf) { return new BuildCityPacket(buf.readBlockPos(), buf.readByte()); }

    public static void handle(BuildCityPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) BuildManager.request(sp, p.pos, p.rot);
        });
        ctx.get().setPacketHandled(true);
    }
}
