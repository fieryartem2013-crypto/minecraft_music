package com.example.citybuilder.client;

import com.example.citybuilder.CityBuilderMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** Клиентское состояние превью: 1-е использование — призрак, 2-е — меню, ОК — стройка. */
public final class ClientHooks {
    public static boolean active;
    public static BlockPos target;     // блок земли под прицелом
    public static int rot;             // 0..3
    public static int yOff;            // сдвиг по высоте

    public static void onUse() {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (!active) {
            active = true; rot = 0; yOff = 0; target = null;
            Skyline.loadAsync();
            p.displayClientMessage(Component.translatable(Skyline.get() == null ? "msg.citybuilder.loading" : "msg.citybuilder.preview"), false);
            if (Skyline.get() == null) p.displayClientMessage(Component.translatable("msg.citybuilder.preview"), false);
            return;
        }
        if (p.isShiftKeyDown()) { cancel(); return; }
        if (target == null) { p.displayClientMessage(Component.translatable("msg.citybuilder.no_target"), true); return; }
        mc.setScreen(new CityScreen());
    }

    public static void cancel() { active = false; target = null; }

    public static BlockPos buildPos() { return target == null ? null : target.offset(0, yOff, 0); }

    /** Вызывается каждый клиентский тик. */
    public static void tick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { cancel(); return; }
        boolean holding = p.getMainHandItem().is(CityBuilderMod.BLUEPRINT.get()) || p.getOffhandItem().is(CityBuilderMod.BLUEPRINT.get());
        if (!holding && !(mc.screen instanceof CityScreen)) { cancel(); return; }
        if (mc.screen == null) {
            HitResult h = p.pick(160.0, 1.0f, false);
            target = h.getType() == HitResult.Type.BLOCK ? ((BlockHitResult) h).getBlockPos() : null;
        }
    }

    private ClientHooks() {}
}
