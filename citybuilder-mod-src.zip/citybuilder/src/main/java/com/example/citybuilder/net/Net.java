package com.example.citybuilder.net;

import com.example.citybuilder.CityBuilderMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CityBuilderMod.MODID, "main"), () -> V, V::equals, V::equals);

    public static void init() {
        CH.registerMessage(0, BuildCityPacket.class, BuildCityPacket::encode, BuildCityPacket::decode, BuildCityPacket::handle);
    }
    private Net() {}
}
