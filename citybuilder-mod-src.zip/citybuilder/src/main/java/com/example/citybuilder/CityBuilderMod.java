package com.example.citybuilder;

import com.example.citybuilder.net.Net;
import net.minecraft.world.item.CreativeModeTabs;
import com.example.citybuilder.build.BuildManager;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CityBuilderMod.MODID)
public class CityBuilderMod {
    public static final String MODID = "citybuilder";
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final RegistryObject<Item> BLUEPRINT =
            ITEMS.register("city_blueprint", () -> new CityBlueprintItem(new Item.Properties().stacksTo(1)));

    public CityBuilderMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        MinecraftForge.EVENT_BUS.addListener((TickEvent.ServerTickEvent e) -> BuildManager.onTick(e));
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
        bus.addListener((BuildCreativeModeTabContentsEvent e) -> {
            if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) e.accept(BLUEPRINT);
        });
    }
}
